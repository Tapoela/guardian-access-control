<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::login');
$routes->match(['GET', 'POST'], 'login', 'Auth::login');
$routes->get('logout', 'Auth::logout');
$routes->get('dashboard', 'Dashboard::index');
$routes->get('admin/users', 'Admin::users');
$routes->match(['GET', 'POST'], 'admin/addUser', 'Admin::addUser');
$routes->match(['GET', 'POST'], 'admin/adduser', 'Admin::addUser'); // Support lowercase URL
$routes->match(['GET', 'POST'], 'admin/editUser/(:num)', 'Admin::editUser/$1');
$routes->get('admin/deleteUser/(:num)', 'Admin::deleteUser/$1');
$routes->get('roles', 'Role::index');
$routes->match(['GET', 'POST'], 'roles/add', 'Role::add');
$routes->match(['GET', 'POST'], 'roles/edit/(:num)', 'Role::edit/$1');
$routes->get('roles/delete/(:num)', 'Role::delete/$1');
$routes->get('settings/permissions', 'Settings::permissions');
$routes->post('settings/togglePermission', 'Settings::togglePermission');
$routes->get('settings/managePermissions', 'Settings::managePermissions');
$routes->post('settings/addPermission', 'Settings::addPermission');
$routes->get('settings/deletePermission/(:num)', 'Settings::deletePermission/$1');

// Access Control – Blacklist
$routes->get('access/blacklist', 'AccessControl::blacklist');
$routes->match(['GET', 'POST'], 'access/blacklist/add', 'AccessControl::addBlacklist');
$routes->match(['GET', 'POST'], 'access/blacklist/edit/(:num)', 'AccessControl::editBlacklist/$1');
$routes->get('access/blacklist/delete/(:num)', 'AccessControl::deleteBlacklist/$1');

// Access Control – Whitelist
$routes->get('access/whitelist', 'AccessControl::whitelist');
$routes->match(['GET', 'POST'], 'access/whitelist/add', 'AccessControl::addWhitelist');
$routes->get('access/whitelist/delete/(:num)', 'AccessControl::deleteWhitelist/$1');

// Access Control – Members
$routes->get('access/members', 'AccessControl::members');
$routes->match(['GET', 'POST'], 'access/members/add', 'AccessControl::addMember');
$routes->match(['GET', 'POST'], 'access/members/edit/(:num)', 'AccessControl::editMember/$1');
$routes->get('access/members/delete/(:num)', 'AccessControl::deleteMember/$1');
$routes->post('access/members/addVehicle/(:num)', 'AccessControl::addVehicle/$1');
$routes->get('access/members/deleteVehicle/(:num)', 'AccessControl::deleteVehicle/$1');

// Access Log & Gate Check (API endpoint for camera/ANPR system)
$routes->get('access/log', 'AccessControl::accessLog');
$routes->post('access/check', 'AccessControl::checkPlate');

// Cameras – management UI
$routes->get('access/cameras', 'Cameras::index');
$routes->match(['GET', 'POST'], 'access/cameras/add', 'Cameras::add');
$routes->match(['GET', 'POST'], 'access/cameras/edit/(:num)', 'Cameras::edit/$1');
$routes->get('access/cameras/delete/(:num)', 'Cameras::delete/$1');
$routes->get('access/cameras/events', 'Cameras::events');
$routes->get('access/cameras/events/poll', 'Cameras::eventsPoll');

// ANPR event receiver – called by Hikvision camera firmware
// URL to configure in camera: http://<server>/anpr/event/<camera_token>
$routes->post('anpr/event/(:any)', 'AnprReceiver::event/$1');

// ANPR snapshot viewer – serves images from writable/ securely (auth required)
$routes->get('anpr/snapshot', 'Snapshot::serve');

//ping route for testing camera connectivity
$routes->get('access/cameras/ping/(:num)', 'Cameras::pingCamera/$1');

//calulate downtime data for cameras
$routes->get('access/cameras/downtimeData', 'Cameras::downtimeData');

