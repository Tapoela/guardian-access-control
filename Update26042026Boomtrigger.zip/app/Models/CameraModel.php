<?php
namespace App\Models;

use CodeIgniter\Model;

class CameraModel extends Model
{
    protected $table         = 'cameras';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'name',
        'location',
        'ip_address',
        'channel',
        'is_active',
        'token',
        'notes',
        'overview_camera_ip',
        'overview_camera_user',
        'overview_camera_pass',
        'overview_snapshot_delay',
        'camera_user',
        'camera_pass',
        'alarm_output_channel',
        'alarm_duration', 
        'is_monitored',
        'last_status', 
    ];
    protected $useTimestamps = false;

    /**
     * Find a camera by its secret token.
     * Returns the camera row or null.
     */
    public function findByToken(string $token): ?array
    {
        return $this->where('token', $token)->where('is_active', 1)->first();
    }

    /**
     * Generate a cryptographically random token.
     */
    public static function generateToken(): string
    {
        return bin2hex(random_bytes(24));
    }
}
