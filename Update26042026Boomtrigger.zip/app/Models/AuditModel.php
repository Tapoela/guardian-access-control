<?php

namespace App\Models;

use CodeIgniter\Model;

class AuditModel extends Model
{
    protected $table      = 'audit_log';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'username', 'action', 'target_type',
        'target_id', 'detail', 'ip_address', 'site_id',
    ];
    protected $useTimestamps  = true;
    protected $createdField   = 'created_at';
    protected $updatedField   = '';   // no updated_at on audit rows

    /**
     * Convenience method — call from any controller.
     *
     * AuditModel::log('blacklist_add', 'blacklist', $id, 'Added ABC123GP');
     */
    public static function log(
        string $action,
        string $targetType = '',
        ?int   $targetId   = null,
        string $detail     = ''
    ): void {
        $session = session();
        $db      = \Config\Database::connect();
        $db->table('audit_log')->insert([
            'user_id'     => $session->get('user_id'),
            'username'    => $session->get('username'),
            'action'      => $action,
            'target_type' => $targetType ?: null,
            'target_id'   => $targetId,
            'detail'      => $detail ?: null,
            'ip_address'  => service('request')->getIPAddress(),
            'site_id'     => $session->get('site_id') !== null ? (int)$session->get('site_id') : null,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
    }
}
