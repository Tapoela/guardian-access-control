<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Dashboard extends Controller
{
    public function index()
    {
        $db = \Config\Database::connect();

        // ── Today's counts ────────────────────────────────────────────
        $today = date('Y-m-d');
        $todayStats = $db->query("
            SELECT
                SUM(result = 'granted')     AS granted,
                SUM(result = 'blacklisted') AS blacklisted,
                SUM(result = 'unknown')     AS unknown,
                SUM(registration = 'NO PLATE') AS no_plate,
                COUNT(*)                    AS total
            FROM anpr_events
            WHERE DATE(created_at) = ?
        ", [$today])->getRowArray();

        // ── Last 7 days traffic (for line chart) ─────────────────────
        $trafficDays = $db->query("
            SELECT
                DATE(created_at)            AS day,
                SUM(result = 'granted')     AS granted,
                SUM(result = 'blacklisted') AS blacklisted,
                SUM(result = 'unknown')     AS unknown,
                SUM(registration = 'NO PLATE') AS no_plate
            FROM anpr_events
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
            GROUP BY DATE(created_at)
            ORDER BY day ASC
        ")->getResultArray();

        // ── Hourly traffic today (for bar chart) ──────────────────────
        $hourlyToday = $db->query("
            SELECT
                HOUR(created_at) AS hour,
                COUNT(*)         AS total
            FROM anpr_events
            WHERE DATE(created_at) = ?
            GROUP BY HOUR(created_at)
            ORDER BY hour ASC
        ", [$today])->getResultArray();

        // ── Top 5 cameras today ───────────────────────────────────────
        $topCameras = $db->query("
            SELECT
                c.name,
                COUNT(*) AS total
            FROM anpr_events e
            LEFT JOIN cameras c ON c.id = e.camera_id
            WHERE DATE(e.created_at) = ?
            GROUP BY e.camera_id
            ORDER BY total DESC
            LIMIT 5
        ", [$today])->getResultArray();

        // ── Yesterday comparison ──────────────────────────────────────
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $yesterdayStats = $db->query("
            SELECT COUNT(*) AS total
            FROM anpr_events
            WHERE DATE(created_at) = ?
        ", [$yesterday])->getRowArray();

        return view('dashboard', [
            'todayStats'    => $todayStats,
            'trafficDays'   => $trafficDays,
            'hourlyToday'   => $hourlyToday,
            'topCameras'    => $topCameras,
            'yesterdayTotal'=> $yesterdayStats['total'] ?? 0,
        ]);
    }
}
