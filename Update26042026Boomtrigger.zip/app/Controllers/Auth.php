<?php
namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class Auth extends Controller
{
    public function login()
    {
        helper(['form']);
        $error = null;
        $debug = [];
        $debug[] = 'Request method: ' . $this->request->getMethod();
        if (strtolower($this->request->getMethod()) === 'post') {
            $debug[] = 'Inside POST block';
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            $debug[] = 'POST email: ' . var_export($email, true);
            $debug[] = 'POST password: ' . ($password ? '[set]' : '[empty]');
            $userModel = new UserModel();
            $debug[] = 'UserModel instantiated';
            $user = $userModel->where('email', $email)->first();
            $debug[] = $user ? 'User found: ' . $user['id'] : 'User not found';
            if ($user) {
                // Fetch role name and id from user_roles and roles tables
                $db = \Config\Database::connect();
                $roleRow = $db->table('user_roles')
                    ->select('roles.id, roles.name')
                    ->join('roles', 'roles.id = user_roles.role_id')
                    ->where('user_roles.user_id', $user['id'])
                    ->get()->getRowArray();
                $roleName = $roleRow && isset($roleRow['name']) ? $roleRow['name'] : '';
                $roleId = $roleRow && isset($roleRow['id']) ? $roleRow['id'] : '';
                $debug[] = 'Role name: ' . $roleName;
                $debug[] = 'Role id: ' . $roleId;
            }
            if (!$user) {
                $error = 'No account found with that email.';
                $debug[] = 'No user found for email.';
            } elseif (!password_verify($password, $user['password_hash'])) {
                $error = 'Incorrect password.';
                $debug[] = 'Password hash in DB: ' . $user['password_hash'];
                $debug[] = 'Password verify failed.';
            } else {
                $db     = \Config\Database::connect();
                $siteId = isset($user['site_id']) && $user['site_id'] !== null ? (int)$user['site_id'] : null;

                // prefer site-specific role, fall back to global (site_id IS NULL)

                
                $roleRow = $db->table('user_roles ur')
                    ->select('r.id, r.name')
                    ->join('roles r', 'r.id = ur.role_id')
                    ->where('ur.user_id', $user['id'])
                    ->groupStart()
                        ->where('ur.site_id', $siteId)
                        ->orWhere('ur.site_id IS NULL', null, false)
                    ->groupEnd()
                    ->orderBy('ISNULL(ur.site_id)', 'ASC', false)
                    ->limit(1)
                    ->get()->getRowArray();

                $roleId   = $roleRow['id']   ?? $user['role_id'] ?? null;
                $roleName = $roleRow['name'] ?? 'operator';

                // resolve site name
                $siteName = 'All Sites';
                if ($siteId !== null) {
                    $siteRow  = $db->table('sites')->select('name')->where('id', $siteId)->get()->getRowArray();
                    $siteName = $siteRow['name'] ?? 'Unknown Site';
                }

                session()->set([
                    'user_id'    => $user['id'],
                    'username'   => $user['username'],
                    'email'      => $user['email'],
                    'role'       => $roleName,
                    'role_id'    => $roleId,
                    'site_id'    => $siteId,
                    'site_name'  => $siteName,
                    'isLoggedIn' => true,
                ]);

                log_message('info', "LOGIN SUCCESS: User ID {$user['id']} ({$user['email']}) Site: {$siteName}");
                return redirect()->to('/dashboard');
            }
// ...existing code...
            if ($error) {
                log_message('warning', 'LOGIN DEBUG: ' . print_r($debug, true));
            }
            return view('login', ['error' => $error ?? null, 'email' => $email ?? '', 'debug' => $debug]);
        }
        return view('login', ['debug' => $debug]);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
