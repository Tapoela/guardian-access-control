<?php
namespace App\Controllers;

use App\Models\UserModel;
use App\Models\SiteModel;
use CodeIgniter\Controller;

class Admin extends Controller
{
    public function users()
    {
        helper(['permission']);
        $session = session();
        if (!$session->get('isLoggedIn') || !hasPermission('user_management')) {
            return redirect()->to('/dashboard');
        }
        $db = \Config\Database::connect();
        $query = $db->table('users')
            ->select('users.id, users.username, users.email, users.site_id,
                      roles.id as role_id, roles.name as role_name,
                      sites.name as site_name')
            ->join('user_roles', 'user_roles.user_id = users.id', 'left')
            ->join('roles', 'roles.id = user_roles.role_id', 'left')
            ->join('sites', 'sites.id = users.site_id', 'left');

        // Non-super-admins only see users from their own site
        if ($session->get('site_id') !== null) {
            $query->where('users.site_id', $session->get('site_id'));
        }

        $users = $query->get()->getResultArray();
        return view('admin/users', ['users' => $users]);
    }

    public function addUser()
    {
        $db    = \Config\Database::connect();
        $sites = $db->table('sites')->where('is_active', 1)->orderBy('name')->get()->getResultArray();
        $roles = $db->table('roles')->orderBy('name')->get()->getResultArray();

        if (strtolower($this->request->getMethod()) === 'post') {
            $username = $this->request->getPost('username');
            $email    = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            $roleId   = (int)$this->request->getPost('role_id');
            $siteId   = $this->request->getPost('site_id') ? (int)$this->request->getPost('site_id') : null;

            // duplicate check
            $exists = $db->table('users')
                ->where('email', $email)->orWhere('username', $username)
                ->countAllResults();
            if ($exists) {
                return redirect()->back()->withInput()
                    ->with('error', 'A user with that email or username already exists.');
            }

            $db->table('users')->insert([
                'username'      => $username,
                'email'         => $email,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'site_id'       => $siteId,
                'role_id'       => $roleId,
                'created_at'    => date('Y-m-d H:i:s'),
            ]);
            $userId = $db->insertID();

            $db->table('user_roles')->insert([
                'user_id' => $userId,
                'role_id' => $roleId,
                'site_id' => $siteId,
            ]);

            \App\Models\AuditModel::log('user_add', 'user', $userId, "Added user {$email} to site_id={$siteId}");
            return redirect()->to('/admin/users')->with('success', 'User added successfully.');
        }

        return view('admin/add_user', ['sites' => $sites, 'roles' => $roles]);
    }

    public function editUser(int $id)
    {
        $db    = \Config\Database::connect();
        $sites = $db->table('sites')->where('is_active', 1)->orderBy('name')->get()->getResultArray();
        $roles = $db->table('roles')->orderBy('name')->get()->getResultArray();
        $user  = $db->table('users')->where('id', $id)->get()->getRowArray();

        if (!$user) return redirect()->to('/admin/users')->with('error', 'User not found.');

        if (strtolower($this->request->getMethod()) === 'post') {
            $roleId = (int)$this->request->getPost('role_id');
            $siteId = $this->request->getPost('site_id') ? (int)$this->request->getPost('site_id') : null;

            $db->table('users')->where('id', $id)->update([
                'username' => $this->request->getPost('username'),
                'email'    => $this->request->getPost('email'),
                'site_id'  => $siteId,
                'role_id'  => $roleId,
            ]);

            $db->table('user_roles')->where('user_id', $id)->delete();
            $db->table('user_roles')->insert([
                'user_id' => $id,
                'role_id' => $roleId,
                'site_id' => $siteId,
            ]);

            \App\Models\AuditModel::log('user_edit', 'user', $id, "Updated user site_id={$siteId} role_id={$roleId}");
            return redirect()->to('/admin/users')->with('success', 'User updated.');
        }

        // get current role assignment
        $currentRole = $db->table('user_roles')->where('user_id', $id)->get()->getRowArray();

        return view('admin/edit_user', [
            'user'        => $user,
            'sites'       => $sites,
            'roles'       => $roles,
            'currentRole' => $currentRole,
        ]);
    }
    
    public function deleteUser($id)
    {
        helper(['permission']);
        $session = session();
        if (!$session->get('isLoggedIn') || !hasPermission('user_management')) {
            return redirect()->to('/dashboard');
        }
        $db = \Config\Database::connect();
        $db->table('user_roles')->where('user_id', $id)->delete();
        (new UserModel())->delete($id);
        session()->setFlashdata('success', 'User deleted successfully.');
        return redirect()->to('/admin/users');
    }
}

