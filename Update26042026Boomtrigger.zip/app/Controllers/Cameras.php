<?php
namespace App\Controllers;

use App\Models\CameraModel;
use CodeIgniter\Controller;

class Cameras extends Controller
{
    private function guard(): bool
    {
        helper(['permission']);
        return session()->get('isLoggedIn') && hasPermission('access_control');
    }

    public function index()
    {
        if (!$this->guard()) return redirect()->to('/dashboard');
        $cameras = (new CameraModel())->orderBy('name')->findAll();
        return view('access/cameras/index', ['cameras' => $cameras]);
    }

    public function add()
    {
        if (!$this->guard()) return redirect()->to('/dashboard');

        if ($this->request->is('post')) {
            $model = new CameraModel();
            $model->insert([
                'name'       => $this->request->getPost('name'),
                'location'   => $this->request->getPost('location'),
                'ip_address' => $this->request->getPost('ip_address'),
                'channel'    => (int) $this->request->getPost('channel') ?: 1,
                'is_active'  => $this->request->getPost('is_active') ? 1 : 0,
                'token'      => CameraModel::generateToken(),
                'notes'      => $this->request->getPost('notes'),
            ]);
            session()->setFlashdata('success', 'Camera added. Copy its token now.');
            return redirect()->to('/access/cameras');
        }
        return view('access/cameras/add');
    }

    public function edit($id)
{
    if (!$this->guard()) return redirect()->to('/dashboard');
    $model  = new CameraModel();
    $camera = $model->find($id);
    if (!$camera) return redirect()->to('/access/cameras');

    if ($this->request->is('post')) {
        $data = [
            'name'                    => $this->request->getPost('name'),
            'location'                => $this->request->getPost('location'),
            'ip_address'              => $this->request->getPost('ip_address'),
            'channel'                 => (int) $this->request->getPost('channel') ?: 1,
            'is_active'               => $this->request->getPost('is_active') ? 1 : 0,
            'notes'                   => $this->request->getPost('notes'),
            'overview_camera_ip'      => $this->request->getPost('overview_camera_ip') ?: null,
            'overview_camera_user'    => $this->request->getPost('overview_camera_user') ?: $camera['overview_camera_user'],
            'overview_camera_pass'    => $this->request->getPost('overview_camera_pass') ?: $camera['overview_camera_pass'],
            'overview_snapshot_delay' => (int) $this->request->getPost('overview_snapshot_delay'),
            'camera_user'             => $this->request->getPost('camera_user') ?: $camera['camera_user'],
            'camera_pass'             => $this->request->getPost('camera_pass') ?: $camera['camera_pass'],
            'alarm_output_channel'    => (int) $this->request->getPost('alarm_output_channel') ?: 1,
            'alarm_duration'          => (int) $this->request->getPost('alarm_duration') ?: 5,
        ];

        if ($this->request->getPost('regen_token')) {
            $data['token'] = CameraModel::generateToken();
            session()->setFlashdata('success', 'Camera updated and token regenerated. Copy the new token now.');
        } else {
            session()->setFlashdata('success', 'Camera updated.');
        }

        if (!$model->update($id, $data)) {
            // Surface DB/validation errors
            session()->setFlashdata('error', implode(', ', $model->errors() ?: ['Database update failed.']));
            return redirect()->back()->withInput();
        }

        return redirect()->to('/access/cameras/edit/' . $id);
    }

    return view('access/cameras/edit', ['camera' => $camera]);
}
    public function delete($id)
    {
        if (!$this->guard()) return redirect()->to('/dashboard');
        (new CameraModel())->delete($id);
        session()->setFlashdata('success', 'Camera deleted.');
        return redirect()->to('/access/cameras');
    }

    // ── ANPR Events viewer ──────────────────────────────────────
    public function events()
    {
        if (!$this->guard()) return redirect()->to('/dashboard');

        $db = \Config\Database::connect();

        $searched  = $this->request->getGet('searched') === '1';
        $cameraId  = $this->request->getGet('camera_id');
        $dateFrom  = $this->request->getGet('date_from');
        $dateTo    = $this->request->getGet('date_to');
        $timeFrom  = $this->request->getGet('time_from') ?: '00:00';
        $timeTo    = $this->request->getGet('time_to')   ?: '23:59';
        $result    = $this->request->getGet('result');

        $builder = $db->table('anpr_events');

        if (!$searched) {
            // Default: grab last 100 rows by primary key — no full table scan
            $builder->orderBy('id', 'DESC')->limit(100);
        } else {
            // Filter form submitted — apply date range and filters, no limit
            $dateFrom = $dateFrom ?: date('Y-m-d');
            $dateTo   = $dateTo   ?: date('Y-m-d');

            $builder->where('created_at >=', $dateFrom . ' ' . $timeFrom . ':00');
            $builder->where('created_at <=', $dateTo   . ' ' . $timeTo   . ':59');

            if ($cameraId) $builder->where('camera_id', (int) $cameraId);
            if ($result)   $builder->where('result', $result);

            $builder->orderBy('created_at', 'DESC');
        }

        $events  = $builder->get()->getResultArray();
        $cameras = (new CameraModel())->where('is_active', 1)->findAll();

        return view('access/cameras/events', [
            'events'    => $events,
            'cameras'   => $cameras,
            'cameraId'  => $cameraId,
            'dateFrom'  => $dateFrom ?: date('Y-m-d'),
            'dateTo'    => $dateTo   ?: date('Y-m-d'),
            'timeFrom'  => $timeFrom,
            'timeTo'    => $timeTo,
            'result'    => $result,
        ]);
    }

    /**
     * GET /access/cameras/events/poll?after=<id>&camera_id=&result=
     * Returns JSON array of new anpr_events rows with id > after,
     * filtered to today only (live feed use-case).
     */
    public function eventsPoll()
    {
        if (!$this->guard()) {
            return $this->response->setStatusCode(403)->setJSON(['error' => 'Forbidden']);
        }

        $db       = \Config\Database::connect();
        $afterId  = (int) $this->request->getGet('after');
        $cameraId = $this->request->getGet('camera_id');
        $result   = $this->request->getGet('result');

        $builder = $db->table('anpr_events')
            ->where('id >', $afterId)
            ->where('DATE(created_at)', date('Y-m-d'))
            ->orderBy('id', 'ASC')
            ->limit(50);

        if ($cameraId) $builder->where('camera_id', (int) $cameraId);
        if ($result)   $builder->where('result', $result);

        $rows = $builder->get()->getResultArray();

        return $this->response->setJSON($rows);
    }

     public function pingCamera($id)
    {
        if (!$this->guard()) return $this->response->setJSON(['online' => false]);

        $camera = (new CameraModel())->find($id);
        if (!$camera || empty($camera['ip_address'])) {
            return $this->response->setJSON(['online' => false, 'reason' => 'No IP configured']);
        }

        $ip      = $camera['ip_address'];
        $online  = false;

        // Try TCP connect on port 80 (HTTP) with 2s timeout
        $sock = @fsockopen($ip, 80, $errno, $errstr, 2);
        if ($sock) {
            fclose($sock);
            $online = true;
        } else {
            // Fallback: try port 8000 (common on Hikvision/Dahua)
            $sock = @fsockopen($ip, 8000, $errno, $errstr, 2);
            if ($sock) {
                fclose($sock);
                $online = true;
            }
        }

        return $this->response->setJSON(['online' => $online, 'ip' => $ip]);
    }

    public function downtimeData()
    {
        if (!$this->guard()) return $this->response->setJSON([]);
        $rows = (new \App\Models\CameraStatusLogModel())->getDowntimeReport();
        return $this->response->setJSON($rows);
    }
}
