<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<div class="row mb-3">
    <div class="col-md-8">
        <h4 class="mb-0"><i class="fas fa-video text-dark mr-2"></i>Cameras</h4>
        <small class="text-muted">ANPR cameras registered to push events to this system.</small>
    </div>
    <div class="col-md-4 text-right">
        <a href="/access/cameras/add" class="btn btn-dark btn-sm">
            <i class="fas fa-plus mr-1"></i> Add Camera
        </a>
        <a href="/access/cameras/events" class="btn btn-outline-secondary btn-sm ml-1">
            <i class="fas fa-list-alt mr-1"></i> ANPR Events
        </a>
    </div>
</div>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?= esc(session()->getFlashdata('success')) ?>
        <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
<?php endif; ?>

<div class="row">
    <?php if (empty($cameras)): ?>
        <div class="col-12">
            <div class="card p-4 text-center text-muted">
                <i class="fas fa-video-slash fa-2x mb-2"></i>
                <p>No cameras registered. <a href="/access/cameras/add">Add one now</a>.</p>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($cameras as $cam): ?>
        <div class="col-md-6 col-lg-4 mb-3">
            <div class="card shadow-sm h-100 <?= $cam['is_active'] ? 'border-left border-success' : 'border-left border-secondary' ?>" style="border-left-width:4px!important;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <h6 class="card-title mb-1">
                            <i class="fas fa-camera mr-1 text-dark"></i>
                            <?= esc($cam['name']) ?>
                        </h6>
                        <?php if ($cam['is_active']): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-secondary">Inactive</span>
                        <?php endif; ?>
                    </div>
                    <p class="text-muted small mb-1">
                        <i class="fas fa-map-marker-alt mr-1"></i><?= esc($cam['location'] ?? '—') ?>
                    </p>
                    <p class="text-muted small mb-1">
                        <i class="fas fa-network-wired mr-1"></i><?= esc($cam['ip_address'] ?? '—') ?>
                        &nbsp;|&nbsp;
                        <i class="fas fa-door-open mr-1"></i>Channel <?= (int)$cam['channel'] ?>
                    </p>
                    <hr class="my-2">
                    <p class="small mb-1"><strong>Listener URL:</strong></p>
                    <code class="small d-block bg-light p-1 rounded text-break">
                        <?= base_url('anpr/event/' . esc($cam['token'])) ?>
                    </code>
                </div>
                <div class="card-footer bg-transparent d-flex justify-content-between">
                    <a href="/access/cameras/edit/<?= $cam['id'] ?>" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-edit mr-1"></i> Edit
                    </a>
                    <a href="/access/cameras/events?camera_id=<?= $cam['id'] ?>" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-history mr-1"></i> Events
                    </a>
                    <a href="/access/cameras/delete/<?= $cam['id'] ?>"
                       class="btn btn-sm btn-outline-danger"
                       onclick="return confirm('Delete camera <?= esc($cam['name']) ?>?')">
                        <i class="fas fa-trash-alt"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Camera Configuration Guide -->
<div class="card shadow-sm mt-3">
    <div class="card-header bg-light">
        <h6 class="mb-0"><i class="fas fa-info-circle mr-2 text-info"></i>How to configure the iDS-2CD7A46G0/P-IZHS</h6>
    </div>
    <div class="card-body small">
        <ol class="mb-0">
            <li>Log into the camera web UI (http://&lt;camera-ip&gt;)</li>
            <li>Go to <strong>Configuration → Network → Advanced Settings → Integration Protocol</strong></li>
            <li>Enable <strong>HTTP Listening</strong> and set the URL to the <em>Listener URL</em> shown on each camera card above.</li>
            <li>Set Method: <code>POST</code></li>
            <li>Under <strong>Configuration → Event → Smart Event → License Plate Recognition</strong>:
                <ul>
                    <li>Enable LPR</li>
                    <li>Set <strong>Linkage Method → Notify Surveillance Center</strong> (this triggers the HTTP push)</li>
                </ul>
            </li>
            <li>Save and test — the camera will POST plate events to your server automatically.</li>
        </ol>
    </div>
</div>

<?= $this->endSection() ?>
