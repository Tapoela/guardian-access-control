<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? esc($title) : 'Dashboard' ?></title>
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        .nav-link-locked {
            opacity: 0.45;
            cursor: not-allowed;
            pointer-events: none;
        }
        .nav-link-locked .lock-icon {
            margin-left: auto;
            font-size: 0.75rem;
            color: #f39c12;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
<?php helper(['permission']); ?>
<div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="/dashboard" class="nav-link">Home</a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <span class="nav-link text-muted">
                    <i class="fas fa-user-circle"></i>
                    <?= esc(session()->get('username') ?? '') ?>
                    <span class="badge badge-secondary ml-1"><?= esc(session()->get('role') ?? '') ?></span>
                </span>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="/dashboard" class="brand-link">
            <span class="brand-text font-weight-light">Guardian Control</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">

                    <!-- Dashboard (always accessible) -->
                    <li class="nav-item">
                        <a href="/dashboard" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>

                    <!-- User Management -->
                    <li class="nav-item">
                        <?php if (hasPermission('user_management')): ?>
                            <a href="/admin/users" class="nav-link">
                                <i class="nav-icon fas fa-users"></i>
                                <p>User Management</p>
                            </a>
                        <?php else: ?>
                            <a href="#" class="nav-link nav-link-locked" title="You do not have access to User Management" data-toggle="tooltip" data-placement="right">
                                <i class="nav-icon fas fa-users"></i>
                                <p>User Management <i class="fas fa-lock lock-icon"></i></p>
                            </a>
                        <?php endif; ?>
                    </li>

                    <!-- Roles -->
                    <li class="nav-item">
                        <?php if (hasPermission('role_management')): ?>
                            <a href="/roles" class="nav-link">
                                <i class="nav-icon fas fa-user-shield"></i>
                                <p>Roles</p>
                            </a>
                        <?php else: ?>
                            <a href="#" class="nav-link nav-link-locked" title="You do not have access to Role Management" data-toggle="tooltip" data-placement="right">
                                <i class="nav-icon fas fa-user-shield"></i>
                                <p>Roles <i class="fas fa-lock lock-icon"></i></p>
                            </a>
                        <?php endif; ?>
                    </li>

                    <!-- Settings -->
                    <li class="nav-item has-treeview">
                        <?php if (hasPermission('settings')): ?>
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-cogs"></i>
                                <p>Settings <i class="right fas fa-angle-left"></i></p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="/settings/permissions" class="nav-link">
                                        <i class="nav-icon fas fa-toggle-on"></i>
                                        <p>Role Permissions</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/settings/managePermissions" class="nav-link">
                                        <i class="nav-icon fas fa-key"></i>
                                        <p>Manage Permissions</p>
                                    </a>
                                </li>
                            </ul>
                        <?php else: ?>
                            <a href="#" class="nav-link nav-link-locked" title="You do not have access to Settings" data-toggle="tooltip" data-placement="right">
                                <i class="nav-icon fas fa-cogs"></i>
                                <p>Settings <i class="fas fa-lock lock-icon"></i></p>
                            </a>
                        <?php endif; ?>
                    </li>

                    <!-- Access Control -->
                    <li class="nav-item has-treeview">
                        <?php if (hasPermission('access_control')): ?>
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-shield-alt"></i>
                                <p>Access Control <i class="right fas fa-angle-left"></i></p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="/access/members" class="nav-link">
                                        <i class="nav-icon fas fa-users"></i>
                                        <p>Members</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/access/whitelist" class="nav-link">
                                        <i class="nav-icon fas fa-check-circle text-success"></i>
                                        <p>Whitelist</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/access/blacklist" class="nav-link">
                                        <i class="nav-icon fas fa-ban text-danger"></i>
                                        <p>Blacklist</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/access/log" class="nav-link">
                                        <i class="nav-icon fas fa-history"></i>
                                        <p>Access Log</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/access/cameras" class="nav-link">
                                        <i class="nav-icon fas fa-video"></i>
                                        <p>Cameras</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/access/cameras/events" class="nav-link">
                                        <i class="nav-icon fas fa-car-alt"></i>
                                        <p>ANPR Events</p>
                                    </a>
                                </li>
                            </ul>
                        <?php else: ?>
                            <a href="#" class="nav-link nav-link-locked" title="You do not have access to Access Control" data-toggle="tooltip" data-placement="right">
                                <i class="nav-icon fas fa-shield-alt"></i>
                                <p>Access Control <i class="fas fa-lock lock-icon"></i></p>
                            </a>
                        <?php endif; ?>
                    </li>

                    <!-- Add more menu items here -->
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <section class="content pt-3">
            <div class="container-fluid">
                <?= $this->renderSection('content') ?>
            </div>
        </section>
    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> Guardian Control.</strong> All rights reserved.
    </footer>
</div>
<!-- ./wrapper -->

<!-- AdminLTE JS -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script>
    // Enable Bootstrap tooltips on locked nav items
    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
</body>
</html>
